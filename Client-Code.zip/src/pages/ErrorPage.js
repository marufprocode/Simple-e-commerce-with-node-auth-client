import React from 'react';

const ErrorPage = () => {
    return (
        <div>
            <h1>Error Page</h1>
        </div>
    );
};

export default ErrorPage;