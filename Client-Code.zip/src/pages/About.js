import React from 'react';

const About = () => {
    return (
        <div>
            <h3 className='text-2xl font-semibold text-center mt-10'>This Website Is made for <span className='text-teal-700'>Ibrat Innovations</span></h3>
        </div>
    );
};

export default About;